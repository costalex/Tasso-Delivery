module.exports = {

  'url' : 'mongodb://ServiceflashDelivery:F0lshD&liveryS&rvices>2017@217.182.136.139:27017/TassoDelivery' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
	
};
