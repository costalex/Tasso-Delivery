function activateCheckbox () {
  if (document.getElementById('cgu_checkbox').checked == false)
  document.getElementById('cgu_checkbox').checked = true;
  else {
    document.getElementById('cgu_checkbox').checked = false;
  }
}
